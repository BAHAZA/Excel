import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Target, BookOpen, CheckCircle, ChevronDown, Star, MessageSquare, Trash2, Edit2, Save } from 'lucide-react';

interface SessionData {
  completed: boolean;
  rating: number | null;
  comment: string;
  isEditing?: boolean;
}

interface SessionStorage {
  [key: number]: SessionData;
}

function StarRating({ rating, onRate }: { rating: number | null; onRate: (rating: number) => void }) {
  return (
    <div className="flex items-center space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          onClick={() => onRate(star)}
          className="focus:outline-none"
        >
          <Star
            className={`w-5 h-5 ${
              (rating && star <= rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
            }`}
          />
        </button>
      ))}
    </div>
  );
}

function Session({ 
  date, 
  time, 
  title, 
  content, 
  isOpen, 
  onToggle,
  sessionIndex,
  sessionData,
  onSessionUpdate
}: { 
  date: string;
  time: string;
  title: string;
  content: string[];
  isOpen: boolean;
  onToggle: () => void;
  sessionIndex: number;
  sessionData: SessionData;
  onSessionUpdate: (index: number, data: SessionData) => void;
}) {
  const [comment, setComment] = useState(sessionData.comment || '');
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    setComment(sessionData.comment || '');
  }, [sessionData.comment]);

  const toggleCompleted = () => {
    onSessionUpdate(sessionIndex, {
      ...sessionData,
      completed: !sessionData.completed
    });
  };

  const handleRate = (rating: number) => {
    onSessionUpdate(sessionIndex, {
      ...sessionData,
      rating
    });
  };

  const handleCommentSubmit = () => {
    if (comment.trim()) {
      onSessionUpdate(sessionIndex, {
        ...sessionData,
        comment: comment.trim()
      });
    }
    setIsEditing(false);
  };

  const handleCommentDelete = () => {
    onSessionUpdate(sessionIndex, {
      ...sessionData,
      comment: ''
    });
    setComment('');
  };

  const startEditing = () => {
    setIsEditing(true);
  };

  return (
    <div className="bg-white rounded-lg shadow-md mb-4 overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50"
      >
        <div className="flex items-center space-x-4">
          <Calendar className="text-blue-600 w-5 h-5" />
          <div className="text-left">
            <h3 className="font-semibold text-gray-900">{date}</h3>
            <div className="flex items-center text-gray-600 text-sm">
              <Clock className="w-4 h-4 mr-1" />
              <span>{time}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleCompleted();
            }}
            className={`p-2 rounded-full transition-colors ${
              sessionData.completed ? 'bg-green-100' : 'bg-gray-100'
            }`}
          >
            <CheckCircle className={`w-5 h-5 ${
              sessionData.completed ? 'text-green-600' : 'text-gray-400'
            }`} />
          </button>
          <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform ${isOpen ? 'transform rotate-180' : ''}`} />
        </div>
      </button>
      
      {isOpen && (
        <div className="px-6 py-4 bg-gray-50">
          <div className="mb-3">
            <h4 className="font-medium text-gray-900 flex items-center">
              <Target className="w-4 h-4 mr-2 text-blue-600" />
              Objectif
            </h4>
            <p className="mt-1 text-gray-700">{title}</p>
          </div>
          <div className="mb-4">
            <h4 className="font-medium text-gray-900 flex items-center">
              <BookOpen className="w-4 h-4 mr-2 text-blue-600" />
              Contenu
            </h4>
            <ul className="mt-1 space-y-2">
              {content.map((item, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="w-4 h-4 mr-2 mt-1 text-green-500" />
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="mb-4">
            <h4 className="font-medium text-gray-900 mb-2">Évaluation de la session</h4>
            <StarRating rating={sessionData.rating} onRate={handleRate} />
          </div>
          <div>
            <h4 className="font-medium text-gray-900 flex items-center mb-2">
              <MessageSquare className="w-4 h-4 mr-2 text-blue-600" />
              Commentaires
            </h4>
            {isEditing ? (
              <div className="space-y-2">
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Laissez vos commentaires sur cette session..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows={3}
                />
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handleCommentSubmit}
                    className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 flex items-center"
                  >
                    <Save className="w-4 h-4 mr-1" />
                    Enregistrer
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                {sessionData.comment ? (
                  <div className="bg-white p-3 rounded-lg border border-gray-200">
                    <p className="text-gray-700">{sessionData.comment}</p>
                    <div className="flex justify-end space-x-2 mt-2">
                      <button
                        onClick={startEditing}
                        className="p-1 text-gray-500 hover:text-blue-600"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={handleCommentDelete}
                        className="p-1 text-gray-500 hover:text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={startEditing}
                    className="text-blue-600 hover:text-blue-700 text-sm flex items-center"
                  >
                    <Edit2 className="w-4 h-4 mr-1" />
                    Ajouter un commentaire
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function App() {
  const [openSession, setOpenSession] = useState<number | null>(0);
  const [sessionProgress, setSessionProgress] = useState<SessionStorage>({});
  
  useEffect(() => {
    const savedProgress = localStorage.getItem('sessionProgress');
    if (savedProgress) {
      setSessionProgress(JSON.parse(savedProgress));
    } else {
      // Initialize empty progress for all sessions
      const initialProgress = sessions.reduce((acc, _, index) => {
        acc[index] = { completed: false, rating: null, comment: '' };
        return acc;
      }, {} as SessionStorage);
      setSessionProgress(initialProgress);
      localStorage.setItem('sessionProgress', JSON.stringify(initialProgress));
    }
  }, []);

  const updateSessionData = (index: number, data: SessionData) => {
    const newProgress = { ...sessionProgress, [index]: data };
    setSessionProgress(newProgress);
    localStorage.setItem('sessionProgress', JSON.stringify(newProgress));
  };

  const completedSessions = Object.values(sessionProgress).filter(s => s.completed).length;
  
  const sessions = [
    {
      date: "19 mars",
      time: "19:30 - 21:00",
      title: "Révision des bases et approfondissement des formules",
      content: [
        "Révision des formules de base",
        "Fonctions intermédiaires : SI, RECHERCHEV"
      ]
    },
    {
      date: "21 mars",
      time: "19:30 - 21:00",
      title: "Mise en forme avancée et gestion des données",
      content: [
        "Mise en forme conditionnelle avancée",
        "Tableaux croisés dynamiques (introduction)"
      ]
    },
    {
      date: "26 mars",
      time: "19:30 - 21:00",
      title: "Graphiques et analyse de données",
      content: [
        "Création de graphiques avancés",
        "Analyse de données avec des tableaux croisés dynamiques"
      ]
    },
    {
      date: "28 mars",
      time: "19:30 - 21:00",
      title: "Automatisation et macros de base",
      content: [
        "Introduction aux macros",
        "Enregistrement et exécution de macros simples"
      ]
    },
    {
      date: "2 avril",
      time: "19:30 - 20:30",
      title: "Révision et pratique",
      content: [
        "Révision des concepts appris",
        "Exercices pratiques et Q&A"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-white mb-4">
            Formation Excel Niveau Intermédiaire
          </h1>
          <p className="text-blue-100 text-lg mb-6">
            Approfondissez vos connaissances et maîtrisez les outils avancés d'analyse et de gestion des données
          </p>
          <div className="flex space-x-4">
            <div className="bg-blue-700 rounded-lg p-4 text-blue-100 inline-flex items-center">
              <Clock className="w-5 h-5 mr-2" />
              <span>5 sessions - 7 heures au total</span>
            </div>
            <div className="bg-blue-700 rounded-lg p-4 text-blue-100 inline-flex items-center">
              <CheckCircle className="w-5 h-5 mr-2" />
              <span>{completedSessions} sessions terminées</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">
            À propos de cette formation
          </h2>
          <p className="text-gray-700 mb-4">
            Cette formation intensive est conçue pour les utilisateurs ayant des connaissances de base d'Excel et souhaitant améliorer leurs compétences. À travers 5 sessions interactives, vous apprendrez à maîtriser les fonctionnalités avancées et à optimiser votre utilisation d'Excel.
          </p>
        </div>

        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Programme des sessions</h2>
          {sessions.map((session, index) => (
            <Session
              key={index}
              {...session}
              isOpen={openSession === index}
              onToggle={() => setOpenSession(openSession === index ? null : index)}
              sessionIndex={index}
              sessionData={sessionProgress[index] || { completed: false, rating: null, comment: '' }}
              onSessionUpdate={updateSessionData}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;